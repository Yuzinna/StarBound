using GameFrameworkLite;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInput : BaseInput,Platformer.IPlayerActions
{
	Platformer input;

	private void OnEnable()
	{
		//TODO ������ start�� ������ �̰��� �ֱ�
	}
	private void Start()
	{
		if (input == null)
		{
			input = InputManager.Instance.Actions;
		}
		if (input != null)
		{
			input.Player.SetCallbacks(this);
			input.Player.Enable();
		}
	}
	private void OnDisable()
	{
		input.Player.Disable();
		input.Player.SetCallbacks(null);
	}
	
	public void OnMove(InputAction.CallbackContext context)
	{
		if (context.performed)
		{
			MoveDir = new Vector2(context.ReadValue<float>(),0);
		}
		if(context.canceled)
		{
			MoveDir = new Vector2(0, 0);
		}
		// Move�� 1D Axis�� ��������� float�� �а�, 2D�� Vector2�� ������ �ȴ�.
		// ���⼭�� 1D ���� (�� -1, 0, 1 ��)
		

		// BaseInput�� ����
		
	}

	public void OnJump(InputAction.CallbackContext context)
	{
		if (context.started)
		{
			OnJumpaction();
		}
	}

	//Ŭ���� �ϸ�
	public void OnInteract(InputAction.CallbackContext context)
	{
		if (context.started)
		{
			OnInteraction();
		}
	}

	public void OnRestart(InputAction.CallbackContext context)
	{
		if (context.started)
		{
			Debug.Log("[PlayerInput] Restart input received");

			var procedure = GameFrameworkEntry.GetModule<ProcedureModule>();

			procedure.ChangeProcedure<ProcedureStage1>();
		}
	}

	public void OnDrop(InputAction.CallbackContext context)
	{
		if (context.started)
		{
			OnDropaction();
		}
	}
}
