﻿using UnityEngine;
// using GameFrameworkLite; // ❗ 프레임워크 사용 안 함

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Collider2D))]
public class GravityObjectLogic : MonoBehaviour // ⬅️ MonoBehaviour로 상속 변경
{
	private Rigidbody2D _rb;
	private Collider2D _col;

	[Header("Floating Movement Settings")]
	public float ascendSpeed = 2f;
	public float floatingUpDrag = 2f;
	public float normalDrag = 0f;

	[Header("Sine Wave Floating Settings")]
	public float floatAmplitude = 0.1f;
	public float floatFrequency = 1f;

	public PhysicsMaterial2D normalMaterial;
	public PhysicsMaterial2D floatingMaterial;

	// --- 내부 상태 변수 ---
	private enum FloatingState { None, Ascending, Waving }
	private FloatingState _floatingStage = FloatingState.None;

	[Header("Debug/Reference")]
	[SerializeField] private Vector3 _floatCenterPosition;
	private float _floatOffset;
	private bool _isFloating;

	//이전에도 둥실 상태였던가?
	private bool prevWaving=false;
	// =========================================================================
	// 유니티 라이프사이클 (MonoBehaviour 표준)
	// =========================================================================

	private bool _isBeingPushedSideways = false; // 플레이어가 옆에서 밀고 있는 중인지
	private int Inverse = -1;

	public LayerMask standableLayers;

	Vector2 curDirection;
	// Raycast 시작 위치를 Collider 밖으로 밀어내기 위한 변수
	private Vector3 _rayStartOffsetPoint;
	// OnInit 대신 Awake 사용
	private void Awake()
	{
		_rb = GetComponent<Rigidbody2D>();
		_col = GetComponent<Collider2D>();

		if (_rb == null || _col == null)
		{
			Debug.LogError("[GravityObjectLogic] Rigidbody2D or Collider2D missing!");
		}

		// 초기 중심점 설정은 Awake에서 한 번만 합니다.
		_floatCenterPosition = transform.position + new Vector3(0, 0.5f, 0);
	}

	// OnShow 대신 Start 사용
	private void Start()
	{
		if (GravityManager.Instance != null)
		{
			// 이 부분은 GravityManager가 MonoBehaviour 상속 Singleton이라고 가정합니다.
			ApplyGravityAndFloatingState(GravityManager.Instance.CurrentDirection,GravityManager.Instance.IsFloatingEnabled);
			curDirection = GravityManager.Instance.CurrentDirection == eGravityDirection.Normal? Vector2.down : Vector2.up;
		}
	}

	// =========================================================================
	// 물리 업데이트 및 상태 처리 (로직 유지)
	// =========================================================================

	private void FixedUpdate()
	{
		// ❗ Debug.DrawRay 수정: _rayStartOffsetPoint에서 발사 시작
		Debug.DrawRay(_rayStartOffsetPoint, curDirection * 100, Color.brown);
		if (!_isFloating) return;

		

		switch (_floatingStage)
		{
			case FloatingState.Ascending:
				HandleAscending();
				break;
			case FloatingState.Waving:
				HandleWaving();
				break;
		}

		// 플로팅 중엔 "기본은 회전만 고정"
		// X 고정은 플레이어가 안 밀 때만
		if (_floatingStage != FloatingState.None)
		{
			if (_isBeingPushedSideways)
				_rb.constraints = RigidbodyConstraints2D.FreezeRotation;
			else
				_rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
		}

		//// ❗ 추가된 로직: Normal 상태에서만 X축 움직임이 멈추면 고정
		//if (!_isFloating && _rb.constraints != (RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation))
		//{
		//	// X축 속도가 0에 가깝다면 다시 X축 고정
		//	if (Mathf.Abs(_rb.linearVelocity.x) < 0.01f)
		//	{
		//		_rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
		//	}
		//}
		//if (!_isBeingPushedSideways && (_rb.constraints & RigidbodyConstraints2D.FreezePositionX) == 0)
		//{
		//	// X축 속도가 0에 매우 가깝다면 X축을 다시 고정합니다.
		//	if (Mathf.Abs(_rb.linearVelocity.x) < 0.01f)
		//	{
		//		// X축 다시 잠금 (Rotation 제약은 유지)
		//		_rb.constraints = _rb.constraints | RigidbodyConstraints2D.FreezePositionX;
		//	}
		//}
	}

	

	private void HandleAscending()
	{
		Debug.Log("Ascending state");
		// 목표 지점(_floatCenterPosition)으로 부드럽게 이동 (X축 Freeze 상태)
		float step = ascendSpeed * Time.fixedDeltaTime;

		// Y만 목표로 이동
		float newY = Mathf.MoveTowards(_rb.position.y, _floatCenterPosition.y, step);
		Vector2 newPos = new Vector2(_rb.position.x, newY);

		_rb.MovePosition(newPos);

		if (Mathf.Abs(_rb.position.y - _floatCenterPosition.y) < 0.001f)
		{
			_floatingStage = FloatingState.Waving;
			_rb.linearVelocity = Vector2.zero;
		}
		//이전에 웨이빙 상태였다면
		if (prevWaving)
		{
			prevWaving = false;
		}
		
	}

	private void HandleWaving()
	{
		Debug.Log("Waving state");
		// 1. 사인파의 Y축 오프셋 계산 및 힘 적용
		float desiredYOffset = Mathf.Sin((Time.time * floatFrequency) + _floatOffset) * floatAmplitude;
		float desiredY = _floatCenterPosition.y + desiredYOffset;

		// 현재 Y 위치와 목표 Y 위치의 차이(오차)를 이용해 복원력 계산
		float forceY = (desiredY - _rb.position.y) * 50f;

		// 2. 힘을 적용하여 Y축을 사인파 궤도로 유지 (X축은 자유롭게 둡니다)
		_rb.AddForce(new Vector2(0f, forceY), ForceMode2D.Force);

		//// 3. 밀릴 수 있도록 제약 조건 해제 (Waving 상태)
		////웨이빙 상태가 아니였을때 그러니까 처음일때
		//if (!prevWaving)
		//{
		//	_rb.constraints = RigidbodyConstraints2D.FreezeRotation;
		//	prevWaving = true;
		//}
		
	}


	// =========================================================================
	// 상태 전환 로직
	// =========================================================================

	public void ApplyGravityAndFloatingState(eGravityDirection direction,bool isFloating)
	{
		if (_rb == null || GravityManager.Instance == null)
			return;

		float baseGravityScale = GravityManager.Instance.normalGravityScale;

		_isFloating = isFloating;

		if(_isFloating)
		{
			// Floating 특성 적용
			_floatingStage = FloatingState.Ascending;
			// 1. 중력 스케일 설정
			float targetGravityScale = (direction == eGravityDirection.Normal)
									   ? GravityManager.Instance.floatingGravityScale
									   : -GravityManager.Instance.floatingGravityScale;
			_rb.gravityScale = targetGravityScale;

			Vector2 rayDirection;
			float offsetDistance; // 장애물로부터의 목표 오프셋 거리
			float rayStartOffsetDistance; // Collider 밖으로 밀어낼 거리
			 // Collider의 절반 크기 + 에러 방지용 작은 값
			rayStartOffsetDistance = _col.bounds.extents.y + 0.01f;

			if (direction == eGravityDirection.Normal)
			{
				// Inverse에서 Normal로 전환: 중력은 아래, 큐브는 바닥 위에 있어야 함.
				// 아래로 레이를 쏴서 바닥을 찾습니다.
				rayDirection = Vector2.down;
				curDirection = rayDirection;
				// 바닥 위 (Y+)로 띄울 목표 오프셋 (floatAmplitude의 중앙)
				offsetDistance = floatAmplitude / 2f + 0.05f;
			}
			else // Inverse
			{
				// Normal에서 Inverse로 전환: 중력은 위, 큐브는 천장 아래에 있어야 함.
				// 위로 레이를 쏴서 천장을 찾습니다.
				rayDirection = Vector2.up;
				curDirection = rayDirection;
				// 천장 아래 (Y-)로 띄울 목표 오프셋
				offsetDistance = -(floatAmplitude / 2f + 0.05f);
				rayStartOffsetDistance = -rayStartOffsetDistance;
			}
			// ❗ 3. 레이캐스트 시작 지점 수정: Collider 경계 밖으로 밀어냄
			// Rigidbody 중심(_rb.position)에서 Ray 방향으로 rayStartOffsetDistance만큼 이동한 지점
			_rayStartOffsetPoint = (Vector3)_rb.position + (Vector3)(rayDirection * rayStartOffsetDistance);
			// 3. 레이캐스트 실행 및 _floatCenterPosition 설정
			RaycastHit2D hit = Physics2D.Raycast(_rayStartOffsetPoint, rayDirection, 100f, standableLayers); // 100f는 충분히 긴 거리
			
			// **중요 수정:** Floating 상태에서도 중력 방향을 반영해야 합니다.
			// Normal이면 (+) floatingGravityScale, Inverse면 (-) floatingGravityScale
			if (direction == eGravityDirection.Normal)
			{
				_rb.gravityScale = GravityManager.Instance.floatingGravityScale;
			}
			else // Inverse
			{
				_rb.gravityScale = -GravityManager.Instance.floatingGravityScale; // 반중력 적용
			}

			_rb.linearDamping = floatingUpDrag;

			// X축 잠금 및 Floating 시작 준비 (Ascending 단계)
			_rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
			//뜨는 중심 좌표값은 중력상태가 정상일때는 아래로 발사 inverse일때는 위로발사해서 충돌한 오브젝트에서 0.5만큼 띄우면됨
			
			// 💡 _floatCenterPosition 계산: Raycast 결과 사용
			if (hit.collider != null)
			{
				_floatCenterPosition = (Vector3)hit.point + new Vector3(0, offsetDistance, 0);
			}
			else
			{
				// 충돌하지 않았을 경우 기본값 또는 안전 거리 설정
				_floatCenterPosition = transform.position + (Vector3)(rayDirection * -1f * 5f);
			}

			_floatOffset = Random.Range(0f, 10f);

			if (floatingMaterial != null && _col != null) _col.sharedMaterial = floatingMaterial;
		}
		else // Floating 또는 InverseFloating
		{
			// Floating 비활성화
			_floatingStage = FloatingState.None;
			_rb.linearDamping = normalDrag;

			// 중력 방향에 따라 일반 중력 스케일 적용
			if (direction == eGravityDirection.Normal)
			{
				_rb.gravityScale = baseGravityScale;
			}
			else // Inverse
			{
				_rb.gravityScale = -baseGravityScale;
			}

			// 중력 방향 설정 시 결정된 기본 중력(_rb.gravityScale = baseGravity)이 그대로 유지됨
			_rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
			_rb.linearVelocity = Vector2.zero; // 정지

			if (normalMaterial != null && _col != null) _col.sharedMaterial = normalMaterial;
		}
	}

	private void OnCollisionEnter2D(Collision2D other)
	{
		CheckSideCollisionAndToggleFreeze(other, true);
	}

	private void OnCollisionExit2D(Collision2D other)
	{
		CheckSideCollisionAndToggleFreeze(other, false);
	}

	private void OnCollisionStay2D(Collision2D other)
	{
		// 충돌이 유지되는 동안에도 옆면 충돌이 맞는지 확인합니다.
		CheckSideCollisionAndToggleFreeze(other, true);
	}
	private void CheckSideCollisionAndToggleFreeze(Collision2D other, bool isEnteringOrStaying)
	{
		// 큐브가 아닌 다른 오브젝트와 충돌한 경우 무시
		if (other.gameObject.GetComponent<PlayerLogic>() == null)
		{
			return;
		}
		//옆면 충돌 체크
		bool sideContact = false;
		// 접촉 지점을 순회하며 옆면 충돌인지 확인합니다.
		foreach (var contact in other.contacts)
		{
			// contact.normal의 x 성분이 크고 y 성분이 작으면 옆면입니다.
			if (Mathf.Abs(contact.normal.x) > 0.5f && Mathf.Abs(contact.normal.y) < 0.5f)
			{
				sideContact = true;
				break;
			}
		}
		_isBeingPushedSideways = isEnteringOrStaying && sideContact;

		// ❗ 핵심: 옆면 충돌 상태에 따라 X축 제약을 제어
		if (_isBeingPushedSideways&&GravityManager.Instance.IsFloatingEnabled==true)
		{
			// 1. 플레이어가 옆에서 밀기 시작하면 X축 제약 해제 (밀리도록 허용)
			_rb.constraints = _rb.constraints & ~RigidbodyConstraints2D.FreezePositionX;
		}
		else if (!isEnteringOrStaying && GravityManager.Instance.IsFloatingEnabled == true) // 충돌을 벗어났을 때 (Exit)
		{
			// 2. 충돌이 끝나면 X축 제약 다시 설정 (멈춰서 미끄러지지 않도록)
			_rb.constraints = _rb.constraints | RigidbodyConstraints2D.FreezePositionX;
		}
	}
}
