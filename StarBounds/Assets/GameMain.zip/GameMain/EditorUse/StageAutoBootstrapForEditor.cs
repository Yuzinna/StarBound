using UnityEngine;
using UnityEngine.SceneManagement;
using GameFrameworkLite;

public class StageAutoBootstrapForEditor : MonoBehaviour
{
	[SerializeField]
	private string entrySceneName = "Entry";

	private void Awake()
	{
#if UNITY_EDITOR
		if (!Application.isPlaying)
			return;

		var framework = FindAnyObjectByType<FrameworkComponent>();
		if (framework != null)
			return;

		Debug.Log("[StageAutoBootstrapForEditor] Framework ���� �� Entry ������ �̵��ؼ� ��Ʈ��Ʈ�� ����");
		SceneManager.LoadScene(entrySceneName);
#endif
	}
}
