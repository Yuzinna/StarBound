// Assets/GameFrameworkLite/DataTable/DataTableModule.cs
using System.Collections.Generic;
using UnityEngine;

namespace GameFrameworkLite
{
	/// <summary>
	/// ������ TextAsset ��� ������ ���̺� ���.
	/// JSON, CSV ���� TextAsset.text�� �Ľ��ؼ� ���.
	/// </summary>
	public sealed class DataTableModule : IGameFrameworkModule
	{
		private readonly ResourceModule _resourceModule;

		// path �� TextAsset
		private readonly Dictionary<string, TextAsset> _tables =
			new Dictionary<string, TextAsset>();

		public DataTableModule(ResourceModule resourceModule)
		{
			_resourceModule = resourceModule;
		}

		/// <summary>
		/// Raw TextAsset �ε�. ���� text �Ľ��� ����ڰ� ����.
		/// </summary>
		public TextAsset LoadRawTable(string path)
		{
			TextAsset asset;
			if (_tables.TryGetValue(path, out asset))
				return asset;

			asset = _resourceModule.Load<TextAsset>(path);
			if (asset != null)
				_tables.Add(path, asset);
			return asset;
		}

		public void Clear()
		{
			_tables.Clear();
		}

		public void Update(float deltaTime, float realDeltaTime) { }

		public void Shutdown()
		{
			Clear();
		}
	}
}
