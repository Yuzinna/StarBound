// Assets/GameFrameworkLite/Scene/SceneModule.cs
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GameFrameworkLite
{
	/// <summary>
	/// �� �ε��� ����ϴ� ������ ���.
	/// </summary>
	public sealed class SceneModule : IGameFrameworkModule
	{
		private bool _isLoading; // �ߺ� �ε� ���� �÷���

		/// <summary>
		/// �� �̸����� �񵿱� �ε� ����.
		/// </summary>
		public void LoadScene(string sceneName)
		{
			if (_isLoading)
			{
				Debug.LogWarning("[SceneModule] Already loading a scene.");
				return;
			}
			Debug.Log($"[SceneModule] LoadScene ȣ��: {sceneName}");

			var go = new GameObject("[SceneLoader]");
			Object.DontDestroyOnLoad(go);
			var loader = go.AddComponent<SceneLoaderHelper>();
			loader.StartCoroutine(LoadSceneCoroutine(sceneName, loader));
		}

		/// <summary>
		/// ���� �񵿱� �ε� �ڷ�ƾ.
		/// </summary>
		private IEnumerator LoadSceneCoroutine(string sceneName, SceneLoaderHelper helper)
		{
			_isLoading = true;
			var op = SceneManager.LoadSceneAsync(sceneName);
			while (!op.isDone)
				yield return null;

			_isLoading = false;
			Object.Destroy(helper.gameObject);
		}

		public void Update(float deltaTime, float realDeltaTime) { }

		public void Shutdown() { }

		// �ڷ�ƾ ����� �ӽ� MonoBehaviour
		private sealed class SceneLoaderHelper : MonoBehaviour { }
	}
}
