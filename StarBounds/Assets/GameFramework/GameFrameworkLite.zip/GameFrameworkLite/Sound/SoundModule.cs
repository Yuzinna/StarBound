// Assets/GameFrameworkLite/Sound/SoundModule.cs
using UnityEngine;

namespace GameFrameworkLite
{
	/// <summary>
	/// BGM / SFX ����� ����ϴ� ������ ���� ���.
	/// </summary>
	public sealed class SoundModule : IGameFrameworkModule
	{
		private readonly ResourceModule _resourceModule;
		private AudioSource _musicSource;   // BGM ��
		private AudioSource _sfxSource;     // ȿ���� ��

		public SoundModule(ResourceModule resourceModule)
		{
			_resourceModule = resourceModule;

			var go = new GameObject("[SoundRoot]");
			Object.DontDestroyOnLoad(go);

			_musicSource = go.AddComponent<AudioSource>();
			_musicSource.loop = true;

			_sfxSource = go.AddComponent<AudioSource>();
		}

		/// <summary>
		/// BGM ���.
		/// path ��: "Audio/Music/MainTheme"
		/// </summary>
		public void PlayMusic(string path, float volume = 1f)
		{
			var clip = _resourceModule.Load<AudioClip>(path);
			if (clip == null) return;
			_musicSource.clip = clip;
			_musicSource.volume = volume;
			_musicSource.Play();
		}

		/// <summary>
		/// BGM ����.
		/// </summary>
		public void StopMusic()
		{
			_musicSource.Stop();
		}

		/// <summary>
		/// ȿ���� �� �� ���.
		/// </summary>
		public void PlaySfx(string path, float volume = 1f)
		{
			var clip = _resourceModule.Load<AudioClip>(path);
			if (clip == null) return;
			_sfxSource.PlayOneShot(clip, volume);
		}

		public void Update(float deltaTime, float realDeltaTime) { }

		public void Shutdown()
		{
			if (_musicSource != null)
				Object.Destroy(_musicSource.gameObject);
		}
	}
}
