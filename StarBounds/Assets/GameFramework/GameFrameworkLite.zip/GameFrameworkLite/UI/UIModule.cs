// Assets/GameFrameworkLite/UI/UIModule.cs
using System.Collections.Generic;
using UnityEngine;

namespace GameFrameworkLite
{
	/// <summary>
	/// ������ UI ���� ���.
	/// - UIRoot(Canvas) �ڵ� ����
	/// - ������ ��η� Open / Close
	/// </summary>
	public sealed class UIModule : IGameFrameworkModule
	{
		private readonly ResourceModule _resourceModule;

		// �̹� �����ִ� UI ��� (path �� UILogic)
		private readonly Dictionary<string, UILogic> _opened = new Dictionary<string, UILogic>();

		// �ֻ��� Canvas
		private Canvas _rootCanvas;

		public UIModule(ResourceModule resourceModule)
		{
			_resourceModule = resourceModule;

			// UIRoot(Canvas) ����
			var canvasGo = new GameObject("[UIRoot]");
			Object.DontDestroyOnLoad(canvasGo);
			_rootCanvas = canvasGo.AddComponent<Canvas>();
			_rootCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
			canvasGo.AddComponent<UnityEngine.UI.CanvasScaler>();
			canvasGo.AddComponent<UnityEngine.UI.GraphicRaycaster>();
		}

		/// <summary>
		/// UI �������� ����.
		/// path ��: "UI/MainMenu"
		/// </summary>
		public UILogic Open(string path, object userData = null)
		{
			if (_opened.ContainsKey(path))
				return _opened[path];

			GameObject go = _resourceModule.Instantiate(path, Vector3.zero, Quaternion.identity, _rootCanvas.transform);
			if (go == null) return null;

			var logic = go.GetComponent<UILogic>();
			if (logic == null)
			{
				Debug.LogError($"[UIModule] UI prefab '{path}' has no UILogic.");
				return null;
			}

			_opened.Add(path, logic);
			logic.OnOpen(userData);
			return logic;
		}

		/// <summary>
		/// �ش� ��η� ���� UI �ݱ�.
		/// </summary>
		public void Close(string path)
		{
			UILogic logic;
			if (_opened.TryGetValue(path, out logic))
			{
				logic.OnClose();
				Object.Destroy(logic.gameObject);
				_opened.Remove(path);
			}
		}

		/// <summary>
		/// ���� ��� UI �ݱ�.
		/// </summary>
		public void CloseAll()
		{
			foreach (var kv in _opened)
			{
				kv.Value.OnClose();
				Object.Destroy(kv.Value.gameObject);
			}
			_opened.Clear();
		}

		public void Update(float deltaTime, float realDeltaTime) { }

		public void Shutdown()
		{
			CloseAll();
			if (_rootCanvas != null)
				Object.Destroy(_rootCanvas.gameObject);
		}
	}
}
