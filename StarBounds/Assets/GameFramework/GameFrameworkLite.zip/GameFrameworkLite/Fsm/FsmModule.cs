// Assets/GameFrameworkLite/Fsm/FsmModule.cs
using System;
using System.Collections.Generic;

namespace GameFrameworkLite
{
	/// <summary>
	/// ���� FSM�� �̸����� �����ϴ� ���.
	/// ��: "Procedure", "PlayerFSM" ��.
	/// </summary>
	public sealed class FsmModule : IGameFrameworkModule
	{
		// �̸� �� FSM �ν��Ͻ� (Ÿ���� �������̶� object�� ����)
		private readonly Dictionary<string, object> _fsms =
			new Dictionary<string, object>();

		/// <summary>
		/// �� FSM ����.
		/// </summary>
		public Fsm<TOwner> CreateFsm<TOwner>(string name, TOwner owner, params FsmState<TOwner>[] states)
			where TOwner : class
		{
			var fsm = new Fsm<TOwner>(owner, states);
			_fsms[name] = fsm;
			return fsm;
		}

		/// <summary>
		/// �̸����� FSM ��������.
		/// </summary>
		public Fsm<TOwner> GetFsm<TOwner>(string name) where TOwner : class
		{
			object fsmObj;
			if (_fsms.TryGetValue(name, out fsmObj))
				return fsmObj as Fsm<TOwner>;
			return null;
		}

		/// <summary>
		/// FSM ���� �� Shutdown ȣ��.
		/// </summary>
		public void DestroyFsm(string name)
		{
			object fsmObj;
			if (_fsms.TryGetValue(name, out fsmObj))
			{
				var shutdownMethod = fsmObj.GetType().GetMethod("Shutdown");
				shutdownMethod?.Invoke(fsmObj, null);
				_fsms.Remove(name);
			}
		}

		/// <summary>
		/// ��ϵ� ��� FSM�� Update ȣ��.
		/// </summary>
		public void Update(float deltaTime, float realDeltaTime)
		{
			foreach (var kv in _fsms)
			{
				var fsmObj = kv.Value;
				var updateMethod = fsmObj.GetType().GetMethod("Update");
				updateMethod?.Invoke(fsmObj, new object[] { deltaTime, realDeltaTime });
			}
		}

		public void Shutdown()
		{
			foreach (var kv in _fsms)
			{
				var fsmObj = kv.Value;
				var shutdownMethod = fsmObj.GetType().GetMethod("Shutdown");
				shutdownMethod?.Invoke(fsmObj, null);
			}
			_fsms.Clear();
		}
	}
}
